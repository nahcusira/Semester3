
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author kami
 */
public class Controller {

    private final Scanner sc = new Scanner(System.in);

    ArrayList<Employee> list = new ArrayList<>();

    public Controller() {
    }

    public ArrayList<Employee> getList() {
        return list;
    }

    public void addEmployee(String id, String fName, String lName, String phone, String email, String address, String dob, String sex, double salary, String egency) {
        list.add(new Employee(id, fName, lName, phone, email, address, dob, sex, salary, egency));
    }

    public boolean checkExist(String id) {
        for (Employee employee : list) {
            if (employee.getId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }

    public int choice(String mess, String err, int min, int max) {
        while (true) {
            try {
                System.out.println(mess);
                int result = Integer.parseInt(sc.nextLine().trim());
                if (result < min || result > max) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (Exception e) {
                System.err.println(err);
            }
        }
    }

    public int inputInt(String mess, String err) {
        while (true) {
            try {
                System.out.println(mess);
                int result = Integer.parseInt(sc.nextLine().trim());
                return result;
            } catch (Exception e) {
                System.err.println(err);
            }
        }
    }

    public String inputPhone(String mess, String err) {
        while (true) {
            try {
                System.out.println(mess);
                String result = sc.nextLine().trim();
                if (result.isEmpty()) {
                    System.err.println(err);
                } else if (!result.matches("[0-9]+")) {
                    System.err.println(err);
                } else {
                    return result;
                }
            } catch (Exception e) {
                System.err.println(err);
            }
        }
    }

    public String inputString(String mess, String err) {
        while (true) {
            try {
                System.out.println(mess);
                String result = sc.nextLine().trim();
                if (result.isEmpty()) {
                    System.err.println(err);
                } else {
                    return result;
                }
            } catch (Exception e) {
                System.err.println(err);
            }
        }
    }

    public double inputDouble(String mess, String err) {
        while (true) {
            try {
                System.out.println(mess);
                double result = Double.parseDouble(sc.nextLine().trim());
                if (result < 0) {
                    System.err.println(err);
                } else {
                    return result;
                }
            } catch (Exception e) {
                System.err.println(err);
            }
        }
    }

    public String intputDate(String mess, String err, String format) {
        SimpleDateFormat sdfin = new SimpleDateFormat(format);
        Date date;
        sdfin.setLenient(false);
        SimpleDateFormat sdfout = new SimpleDateFormat(format);
        System.out.println(mess);
        while (true) {
            try {
                mess = sc.nextLine().trim();
                date = sdfin.parse(mess);
                Date now = new Date();
                String txt[] = mess.split("/");
                int year = Integer.parseInt(txt[2]);
                int age = 2021 - year;
                if (date.after(now) || age < 18) {
                    System.err.println(err);
                    continue;
                }
                break;
            } catch (Exception e) {
                System.err.println(err);
            }
            try {
                date = sdfout.parse(mess);
                break;
            } catch (Exception e) {
                System.err.println(err);
            }
        }
        return sdfout.format(date);
    }

    public Employee getIdEmployee(String id) {
        for (Employee employee : list) {
            if (employee.getId().equalsIgnoreCase(id)) {
                return employee;
            }
        }
        return null;
    }

    public void updateEmployee(String id, String fName, String lName, String phone, String email, String address, String dob, String sex, double salary, String egency) {
        Employee employee = getIdEmployee(id);
        employee.setfName(fName);
        employee.setlName(lName);
        employee.setPhone(phone);
        employee.setEmail(email);
        employee.setAddress(address);
        employee.setDob(dob);
        employee.setSex(sex);
        employee.setSalary(salary);
        employee.setEgency(egency);
    }

    public void remove(String id) {
        Employee employee = getIdEmployee(id);
        if (employee == null) {
            return;
        } else {
            list.remove(employee);
        }
    }

    public ArrayList<Employee> searchEmployee(String searchValue) {
        ArrayList<Employee> listSearch = new ArrayList<>();
        for (Employee employee : list) {
            if (employee.getfName().toLowerCase().contains(searchValue) || employee.getlName().toLowerCase().contains(searchValue)) {
                listSearch.add(employee);
            }
        }
        return listSearch;
    }

    public ArrayList<Employee> sortEmployee() {
        list.sort(Comparator.comparing(Employee::getSalary));
        return list;
    }

}
