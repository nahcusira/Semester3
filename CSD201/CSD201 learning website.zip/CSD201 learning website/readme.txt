Double click on the file index.htm to open the website in a browser.
